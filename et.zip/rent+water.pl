#!/usr/bin/perl
use PostScript::Simple;
use POSIX qw(ceil floor);

#my %rent = (Jon => 469, Jeremy => 423, Arya => 516);
my %rent = (Jeremy => 438, Jon => 486.67, Arya => 535.33);
my $trash = 3;
my $water = $ARGV[0];
my $utils = $water + $trash;
die "usage: $0 <water_bill_amount>\n" unless $water;
my $small = floor($utils * 100 / 3);
my %utils = (Jon => $small/100, Jeremy => $small/100, Arya => $water-2*$small/100);

my $p = new PostScript::Simple(papersize => "Letter", 
			       units => "in",
			       eps => 0);
$p->setfont("Times-Roman", 20);

my ($x1,$y1) = (1,.5);
my ($x2,$y2) = ($x1+6.5,$y1+3);

for $i (keys %rent) {
  my $total = $rent{$i} + $utils{$i};
  my $string = sprintf('%s: $%d + $%.2f = $%.2f', $i, $rent{$i}, $utils{$i}, $total);#"$i: \$$rent{$i} + \$$utils{$i} = \$$total";
  print "$string\n";
  $p->box($x1,$y1, $x2,$y2);
  $p->text($x1+.5,$y2-.5, $string);
  $y1 = $y2 + .5;
  $y2 = $y1 + 3;
}

## Doesn't work with BSD 'date'
# my $date;
# if (`date +\%e` > 6) {
#   $date = `date '+\%B \%Y' -d 'next month'`;
# } else {
#   $date = `date '+\%B \%Y'`;
# }

$p->output("/tmp/file.ps");
exec "open /tmp/file.ps";

print "don't forget $3.66 for april"
